libfreenect wrapper for Max/MSP Jitter.

Copyright 2010, Jean-Marc Pelletier, Nenad Popov and Andrew Roth.

For latest info on Kinect in Max check the Kinect wiki hosted by c74:
https://cycling74.com/wiki/index.php?title=Kinect_Page

Source code at:
https://github.com/npnp/jit.freenect.grab.git

For any questions, feel free to contact nesa.popov@gmail.com